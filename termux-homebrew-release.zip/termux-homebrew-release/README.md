# Termux Homebrew 🍻📱

Homebrew for Android via Termux — run Linux tools on Android easily.
See wiki/ and scripts for details.
