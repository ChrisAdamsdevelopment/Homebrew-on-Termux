#!/usr/bin/env bash
echo 'Installing Homebrew on Termux...'