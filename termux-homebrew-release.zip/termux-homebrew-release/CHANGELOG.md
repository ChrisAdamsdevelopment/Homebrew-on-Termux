## v1.0.0
- Initial release of Homebrew on Termux.